import java.io.*;
import java.util.Arrays;
import java.util.Scanner;


public class Lab10_Q1{

    public static void main(String args[]) throws IOException {
    File f1 = new File("one.txt");
    File f2 = new File("two.txt");
        Scanner scanner = new Scanner(System.in);
    boolean onesTurn = true;
        FileWriter fw1 = new FileWriter(f1);
        FileWriter fw2 = new FileWriter(f2);
    String input ="";
    while(!input.equals("eeeee")){

        if(onesTurn){
            System.out.println("ones turn to write");
            input = scanner.nextLine();
            fw1.write("You: "+ input+"\n");
            fw2.write("Other: "+input+"\n");
        }
        else{
            System.out.println("twos turn to write");
            input = scanner.nextLine();
            fw2.write("You: "+ input+"\n");
            fw1.write("Other: "+input+"\n");
        }
        onesTurn = !onesTurn;
    }
    fw1.close();
    fw2.close();
    Scanner reader = new Scanner(f1);
    while(reader.hasNextLine()){
        System.out.println(reader.nextLine());
    }
        System.out.println("<=============>");

    reader = new Scanner(f2);
        while(reader.hasNextLine()){
            System.out.println(reader.nextLine());
        }
    }
}