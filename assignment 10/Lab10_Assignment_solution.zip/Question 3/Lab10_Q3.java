import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

public class Lab10_Q3 {
    public static void main(String[] args) {
        Scanner scanner =new Scanner(System.in);
        System.out.println("Enter your string");
        String str = scanner.nextLine();
                try {
                    InputStream stream = new ByteArrayInputStream(str.getBytes());
                    while(stream.available()>0) {
                        System.out.print((char)stream.read() + " : ");
                        System.out.println("Bytes remaining in the stream are " + stream.available());
                    }
                    stream.close();
                }

                catch (Exception e) {
                    e.getStackTrace();
                }
            }
        }